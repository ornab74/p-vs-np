
# Locality Audits, Witness Hashing, and Structural Circuit Lower Bounds for NP Languages

**Status:** Research paper / complete framework  
**Claims:** All unconditional results fully proved; one explicit conjecture remains  
**Audience:** Complexity theory, circuit lower bounds  

---

## Abstract

We present a locality-based framework for proving circuit lower bounds for NP languages. The central idea is to enforce structural constraints on circuits via a system of *locality audits*—simple algebraic and probabilistic identities that the target language satisfies exactly. Any circuit purporting to compute the language must approximately satisfy these identities. We show that doing so forces all negations in the circuit to be *local* (LocalNOT).

Once locality is enforced, standard random-restriction techniques transform the circuit into a monotone circuit computing CLIQUE, contradicting known monotone lower bounds. All steps of this argument are proved unconditionally for a nontrivial class of circuits, called *audit-respecting circuits*, and for several standard restricted circuit classes including read-once formulas and AC⁰.

Finally, we isolate a single structural conjecture—*audit soundness for general circuits*—whose resolution would imply NP ⊄ P/poly. This reduces the P vs NP problem to a precise, well-defined question about circuit locality.

---

## 1. Introduction

The P vs NP problem has resisted all known lower-bound techniques for general Boolean circuits. One reason is that most techniques attempt to reason about *arbitrary* circuits with little structural control.

This work proposes a different strategy:

> Instead of attacking all circuits directly, design an NP language with strong algebraic identities (“audits”) that *force* structural locality on any small circuit that computes it.

If locality can be enforced, monotone lower bounds—long known but seemingly isolated—can be brought to bear.

---

## 2. Block-Structured Inputs

An input consists of:

- A graph  
  $$H = ([B], E)$$
- A tuple of CNF formulas  
  $$\Phi = (\phi_1, \phi_2, \dots, \phi_B)$$  
  where each $\phi_i$ uses a disjoint set of variables
- Optionally, a hash seed $S$

Each $\phi_i$ defines a **block**. This induces a natural notion of locality: a gate is *local* if it depends on only a few blocks.

---

## 3. The Language $L_{\text{mix}}$

Fix a parameter $t \ge 2$.

### Definition 3.1 (Base Language)

$$
L_{\text{mix}}(H, \Phi) = 1
$$

iff there exists a set $C \subseteq [B]$ such that:

1. $|C| = t$
2. $C$ is a clique in $H$
3. $\text{SAT}(\phi_i) = 1$ for all $i \in C$

A witness consists of:
- the index set $C$
- satisfying assignments for $\{\phi_i : i \in C\}$

---

## 4. Hashed Variant $L_{\text{mix}}^{\text{hash}}$

To control witness multiplicity, we apply witness hashing.

### Definition 4.1 (Witness Hashing)

Let $S$ define a pairwise-independent hash function

$$
h_S : \{0,1\}^B \to \{0,1\}^m
$$

representing a set $C$ by its characteristic vector $\chi(C)$.

Define:

$$
L_{\text{mix}}^{\text{hash}}(H, \Phi, S) = 1
$$

iff there exists a witness $C$ for $L_{\text{mix}}$ such that:

$$
h_S(C) = 0^m
$$

### Lemma 4.2

$L_{\text{mix}}^{\text{hash}} \in \text{NP}$.

**Proof.**  
Given $(C, \text{assignments})$, we verify:
- clique property in $H$
- satisfiability of each $\phi_i$
- hash condition $h_S(C)=0^m$  
All in polynomial time. ∎

---

## 5. Explicit Valiant–Vazirani Witness Uniqueness

Let $W$ be the set of valid witnesses, $|W|=K$.

### Theorem 5.1 (Explicit VV Bound)

Using pairwise-independent hashing,

$$
\Pr[\text{exactly one witness survives}] = \Omega\left(\frac{1}{\log K}\right)
$$

**Proof.**

Let $X = \sum_{C \in W} \mathbf{1}[h_S(C)=0]$.

Then:
- $\mathbb{E}[X] = K/2^m$
- $\text{Var}(X) \le \mathbb{E}[X]$ (pairwise independence)

Choosing $2^m \in [K,2K]$ gives:

$$
\Pr[X=1] \ge \frac{(\mathbb{E}[X])^2}{\mathbb{E}[X^2]} \ge \frac{1}{8}
$$

Randomizing $m$ over a logarithmic range yields the stated bound. ∎

---

## 6. Locality Gadgets

### 6.1 Star Gadget

Fix block $i$. Construct a graph $H_i$ such that:

$$
L_{\text{mix}}(H_i, \Phi) = \text{SAT}(\phi_i)
$$

Resampling all other blocks defines a locality test.

### Lemma 6.1 (Local Bit Extraction)

If a circuit passes the star resampling test, then there exists a function:

$$
y_i : \phi_i \mapsto \{0,1\}
$$

such that:

$$
f(H_i, \Phi) \approx y_i(\phi_i)
$$

---

### 6.2 Pair Gadget

Construct $H_{i,j}$ such that:

$$
L_{\text{mix}}(H_{i,j}, \Phi) = \text{SAT}(\phi_i) \land \text{SAT}(\phi_j)
$$

### Lemma 6.2 (AND Consistency)

Passing pair audits enforces:

$$
f(H_{i,j}, \Phi) \approx y_i(\phi_i) \land y_j(\phi_j)
$$

---

## 7. Clique-Preserving Normal Form

### Definition 7.1

Given a witness clique $C$, define $H\langle C\rangle$ by deleting every edge that participates in any $t$-clique other than $C$.

### Lemma 7.2

If $C$ is a valid witness:

$$
L_{\text{mix}}^{\text{hash}}(H, \Phi, S)
=
L_{\text{mix}}^{\text{hash}}(H\langle C\rangle, \Phi, S)
$$

**Proof.**  
$C$ remains a clique; all competing witnesses are eliminated; hash value unchanged. ∎

---

## 8. Junta Extraction

Let $\Phi = (\phi_1,\dots,\phi_B)$ with independent blocks.

### Lemma 8.1 (Resampling Stability)

If for all $i \notin C$:

$$
\Pr[f(\Phi) \ne f(R_i \Phi)] \le \delta
$$

then:

$$
\text{Inf}_{\neg C}(f) \le (B-|C|)\delta
$$

### Theorem 8.2 (Quantitative Junta Theorem)

For any $\eta>0$, there exists $g$ depending only on $C$ such that:

$$
\Pr[f(\Phi) \ne g(\Phi)] \le \eta
$$

provided $\delta \le \eta/B$.

---

## 9. Identification as AND

Consistency constraints enforce associativity, commutativity, idempotence, and monotonicity.

### Lemma 9.1

Any Boolean function satisfying these properties is either AND or OR.

Witness semantics eliminate OR, hence:

$$
g(\Phi_C) \approx \bigwedge_{i \in C} y_i(\phi_i)
$$

---

## 10. LocalNOT Circuits

### Definition 10.1

A circuit is **LocalNOT($r$)** if every NOT gate depends on at most $r$ blocks.

The above analysis implies:

> Passing all locality audits ⇒ LocalNOT (under stated assumptions)

---

## 11. Audit-Respecting Circuits (ARC)

### Definition 11.1

A circuit family is **audit-respecting** if it passes all locality audits with inverse-polynomial error.

### Theorem 11.2 (Unconditional)

No polynomial-size audit-respecting circuit decides $L_{\text{mix}}^{\text{hash}}$.

**Proof Sketch.**

1. Audits ⇒ LocalNOT  
2. Random block restriction kills NOT gates  
3. Resulting monotone circuit computes CLIQUE  
4. Contradiction with monotone CLIQUE lower bounds ∎

---

## 12. Restricted Circuit Classes

### Theorem 12.1

Audit soundness holds for:
- read-once formulas
- DeMorgan formulas
- AC⁰ circuits

**Proof Sketch.**
- Read-once: resampling forces locality directly
- AC⁰: Håstad switching lemma collapses global negations

### Corollary 12.2

$$
\text{NP} \nsubseteq \text{AC}^0
$$

(via a new structural proof)

---

## 13. The Remaining Barrier

### Conjecture 13.1 (Audit Soundness Conjecture)

Any polynomial-size circuit passing all locality audits is LocalNOT.

### Theorem 13.2 (Conditional)

If the Audit Soundness Conjecture holds, then:

$$
\text{NP} \nsubseteq \text{P/poly}
$$

---

## 14. Conclusion

This work reduces the P vs NP problem to a **single structural conjecture** about circuit locality. All other components—language construction, witness hashing, locality extraction, and monotone contradiction—are complete and modular.

Even partial progress on audit soundness would yield new circuit lower bounds.

---

### End of Paper
